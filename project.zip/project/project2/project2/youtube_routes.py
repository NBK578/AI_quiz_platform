# youtube_routes.py
import os
from flask import Blueprint, render_template, request, redirect, url_for, session, send_file, flash, current_app
from youtube_utils import youtube_to_pdf

youtube_bp = Blueprint('youtube', __name__)

@youtube_bp.route('/youtube_to_pdf', methods=['GET', 'POST'])
def youtube_to_pdf_route():
    if request.method == 'GET':
        return render_template('youtube_form.html')
    url = request.form.get('youtube_url', '').strip()
    if not url:
        flash('유튜브 링크를 입력해주세요.')
        return redirect(url_for('youtube.youtube_to_pdf_route'))
    try:
        pdf_path, filename = youtube_to_pdf(url)
        session['youtube_pdf'] = filename
        return render_template('youtube_result.html', filename=filename)
    except Exception as e:
        flash(f'처리 중 오류 발생: {e}')
        return redirect(url_for('youtube.youtube_to_pdf_route'))

@youtube_bp.route('/download_youtube_pdf/<filename>')
def download_youtube_pdf(filename):
    path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    return send_file(path, as_attachment=True)
